- 👋 Hi, I’m @princessorbillo
- 👀 I’m interested in music and programming
- 🌱 I’m currently learning OpenGL and MATLAB for my course subs 
- 💞️ I’m looking to collaborate on ...
- 📫 Email: orbilloprincessmorera@gmail.com
- 😄 Pronouns: They/Them
- ⚡ Fun fact: I'm very tall

<!---
princessorbillo/princessorbillo is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
